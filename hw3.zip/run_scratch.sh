python train_t5.py --max_n_epochs 100  --patience_epochs 30 --learning_rate 1e-4 --batch_size 32
