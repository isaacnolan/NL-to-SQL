python train_t5.py --experiment_name experiment --max_n_epochs 0  --patience_epochs 0 --learning_rate 1e-4 --batch_size 32
