import os
import argparse
import pickle
from tqdm import tqdm

import torch
import torch.nn as nn
import numpy as np
import wandb

from t5_utils import initialize_model, initialize_optimizer_and_scheduler, save_model, load_model_from_checkpoint, setup_wandb
from transformers import GenerationConfig
from load_data import load_t5_data
from utils import compute_metrics, save_queries_and_records, compute_records

# ...existing code...
if torch.cuda.is_available():
    DEVICE = torch.device("cuda")
elif torch.backends.mps.is_available():
    DEVICE = torch.device("mps")
    
else:
    DEVICE = torch.device("cpu")
print(f'Using device: {DEVICE}')
PAD_IDX = 0

def get_args():
    '''
    Arguments for training. You may choose to change or extend these as you see fit.
    '''
    parser = argparse.ArgumentParser(description='T5 training loop')

    # Model hyperparameters
    parser.add_argument('--finetune', action='store_true', help="Whether to finetune T5 or not")
    
    # Training hyperparameters
    parser.add_argument('--optimizer_type', type=str, default="AdamW", choices=["AdamW"],
                        help="What optimizer to use")
    parser.add_argument('--learning_rate', type=float, default=1e-3)
    parser.add_argument('--weight_decay', type=float, default=0)

    parser.add_argument('--scheduler_type', type=str, default="cosine", choices=["none", "cosine", "linear"],
                        help="Whether to use a LR scheduler and what type to use if so")
    parser.add_argument('--num_warmup_epochs', type=int, default=0,
                        help="How many epochs to warm up the learning rate for if using a scheduler")
    parser.add_argument('--max_n_epochs', type=int, default=0,
                        help="How many epochs to train the model for")
    parser.add_argument('--patience_epochs', type=int, default=0,
                        help="If validation performance stops improving, how many epochs should we wait before stopping?")

    parser.add_argument('--use_wandb', action='store_true',
                        help="If set, we will use wandb to keep track of experiments")
    parser.add_argument('--experiment_name', type=str, default='experiment',
                        help="How should we name this experiment?")

    # Data hyperparameters
    parser.add_argument('--batch_size', type=int, default=16)
    parser.add_argument('--test_batch_size', type=int, default=16)

    args = parser.parse_args()
    return args

def train(args, model, train_loader, dev_loader, optimizer, scheduler):
    best_f1 = -1
    epochs_since_improvement = 0
    experiment_name = args.experiment_name
    model_type = 'ft' if args.finetune else 'scr'
    checkpoint_dir = os.path.join('checkpoints', f'{model_type}_experiments', args.experiment_name)
    gt_sql_path = os.path.join(f'data/dev.sql')
    gt_record_path = os.path.join(f'records/ground_truth_dev.pkl')
    model_sql_path = os.path.join(f'results/t5_{model_type}_{experiment_name}_dev.sql')
    model_record_path = os.path.join(f'records/t5_{model_type}_{experiment_name}_dev.pkl')
    for epoch in range(args.max_n_epochs):
        tr_loss = train_epoch(args, model, train_loader, optimizer, scheduler)
        print(f"Epoch {epoch}: Average train loss was {tr_loss}")

        eval_loss, record_f1, record_em, sql_em, error_rate = eval_epoch(args, model, dev_loader,
                                                                         gt_sql_path, model_sql_path,
                                                                         gt_record_path, model_record_path)
        print(f"Epoch {epoch}: Dev loss: {eval_loss}, Record F1: {record_f1}, Record EM: {record_em}, SQL EM: {sql_em}")
        print(f"Epoch {epoch}: {error_rate*100:.2f}% of the generated outputs led to SQL errors")

        if args.use_wandb:
            result_dict = {
                'train/loss' : tr_loss,
                'dev/loss' : eval_loss,
                'dev/record_f1' : record_f1,
                'dev/record_em' : record_em,
                'dev/sql_em' : sql_em,
                'dev/error_rate' : error_rate,
            }
            wandb.log(result_dict, step=epoch)

        if record_f1 > best_f1:
            best_f1 = record_f1
            epochs_since_improvement = 0
        else:
            epochs_since_improvement += 1

        save_model(checkpoint_dir, model, best=False)
        if epochs_since_improvement == 0:
            save_model(checkpoint_dir, model, best=True)

        if epochs_since_improvement >= args.patience_epochs:
            break

def train_epoch(args, model, train_loader, optimizer, scheduler):
    model.train()
    total_loss = 0
    total_tokens = 0
    criterion = nn.CrossEntropyLoss()

    for encoder_input, encoder_mask, decoder_input, decoder_targets, _ in tqdm(train_loader):
        optimizer.zero_grad()
        encoder_input = encoder_input.to(DEVICE)
        encoder_mask = encoder_mask.to(DEVICE)
        decoder_input = decoder_input.to(DEVICE)
        decoder_targets = decoder_targets.to(DEVICE)

        logits = model(
            input_ids=encoder_input,
            attention_mask=encoder_mask,
            decoder_input_ids=decoder_input,
        )['logits']

        non_pad = decoder_targets != PAD_IDX
        loss = criterion(logits[non_pad], decoder_targets[non_pad])
        loss.backward()
        optimizer.step()
        if scheduler is not None: 
            scheduler.step()

        with torch.no_grad():
            num_tokens = torch.sum(non_pad).item()
            total_loss += loss.item() * num_tokens
            total_tokens += num_tokens

    return total_loss / total_tokens
        
def eval_epoch(args, model, dev_loader, gt_sql_pth, model_sql_path, gt_record_path, model_record_path):
    '''
    You must implement the evaluation loop to be using during training. We recommend keeping track
    of the model loss on the SQL queries, the metrics compute_metrics returns (save_queries_and_records should be helpful)
    and the model's syntax error rate. 

    To compute non-loss metrics, you will need to perform generation with the model. Greedy decoding or beam search
    should both provide good results. If you find that this component of evaluation takes too long with your compute,
    we found the cross-entropy loss (in the evaluation set) to be well (albeit imperfectly) correlated with F1 performance.
    '''
    
    model.eval()

    device = DEVICE
    criterion = nn.CrossEntropyLoss()

    total_loss = 0.0
    total_tokens = 0

    # Compute cross-entropy loss across the dev set
    with torch.no_grad():
        for batch in tqdm(dev_loader):
            # Expect batch: encoder_input, encoder_mask, decoder_input, decoder_targets, initial_decoder_inputs
            if len(batch) == 5:
                encoder_input, encoder_mask, decoder_input, decoder_targets, _ = batch
            else:
                encoder_input, encoder_mask, decoder_input, decoder_targets = batch[:4]

            # Move tensors to model device to avoid device mismatch (cpu vs cuda/mps)
            encoder_input = encoder_input.to(device)
            encoder_mask = encoder_mask.to(device)
            decoder_input = decoder_input.to(device)
            decoder_targets = decoder_targets.to(device)

            outputs = model(input_ids=encoder_input, attention_mask=encoder_mask, decoder_input_ids=decoder_input)['logits']

            non_pad = decoder_targets != PAD_IDX
            if torch.any(non_pad):
                loss = criterion(outputs[non_pad], decoder_targets[non_pad])
                num_tokens = torch.sum(non_pad).item()
                total_loss += loss.item() * num_tokens
                total_tokens += num_tokens

    eval_loss = total_loss / total_tokens if total_tokens > 0 else 0.0

    # Generate SQL for the entire dev set (using encoder inputs from dev_loader)
    tokenizer = dev_loader.dataset.tokenizer
    generated_queries = []

    with torch.no_grad():
        for batch in tqdm(dev_loader):
            if len(batch) == 5:
                encoder_input, encoder_mask, *_ = batch
            else:
                encoder_input, encoder_mask = batch[0], batch[1]

            encoder_input = encoder_input.to(device)
            encoder_mask = encoder_mask.to(device)

            # Greedy generation; cap token length
            gen_ids = model.generate(input_ids=encoder_input, attention_mask=encoder_mask, max_new_tokens=200)
            decoded = tokenizer.batch_decode(gen_ids, skip_special_tokens=True)
            for d in decoded:
                generated_queries.append(d.strip())

    # Save generated queries and compute records
    save_queries_and_records(generated_queries, model_sql_path, model_record_path)

    # Compute metrics comparing generated queries to ground-truth
    sql_em, record_em, record_f1, model_error_msgs = compute_metrics(gt_sql_pth, model_sql_path, gt_record_path, model_record_path)

    error_count = sum(1 for m in model_error_msgs if m)
    error_rate = error_count / max(1, len(model_error_msgs))

    # Return (eval_loss, record_f1, record_em, sql_em, error_rate)
    return eval_loss, record_f1, record_em, sql_em, error_rate
        
def test_inference(args, model, test_loader, model_sql_path, model_record_path):
    '''
    You must implement inference to compute your model's generated SQL queries and its associated 
    database records. Implementation should be very similar to eval_epoch.
    '''
    model.eval()

    device = DEVICE
    tokenizer = test_loader.dataset.tokenizer
    generated_queries = []

    with torch.no_grad():
        for batch in tqdm(test_loader):
            if len(batch) == 3:
                encoder_input, encoder_mask, _ = batch
            else:
                encoder_input, encoder_mask = batch[0], batch[1]

            encoder_input = encoder_input.to(device)
            encoder_mask = encoder_mask.to(device)

            gen_ids = model.generate(
                input_ids=encoder_input,
                attention_mask=encoder_mask,
                max_new_tokens=200,
            )
            decoded = tokenizer.batch_decode(gen_ids, skip_special_tokens=True)
            generated_queries.extend(d.strip() for d in decoded)

    os.makedirs(os.path.dirname(model_sql_path), exist_ok=True)
    os.makedirs(os.path.dirname(model_record_path), exist_ok=True)

    # Save queries and records, and compute inference-time SQL error rate
    records, error_msgs = compute_records(generated_queries)
    with open(model_sql_path, 'w') as f:
        for query in generated_queries:
            f.write(f"{query}\n")
    with open(model_record_path, 'wb') as f:
        pickle.dump((records, error_msgs), f)

    error_count = sum(1 for msg in error_msgs if msg)
    error_rate = error_count / max(1, len(error_msgs))
    print(f"Test inference complete. {error_rate*100:.2f}% of generated outputs led to SQL errors")

def main():
    # Get key arguments
    args = get_args()
    if args.use_wandb:
        # Recommended: Using wandb (or tensorboard) for result logging can make experimentation easier
        setup_wandb(args)

    # Load the data and the model
    train_loader, dev_loader, test_loader = load_t5_data(args.batch_size, args.test_batch_size)
    

    # Prepare checkpoint directory
    experiment_name = args.experiment_name
    model_type = 'ft' if args.finetune else 'scr'
    checkpoint_dir = os.path.join('checkpoints', f'{model_type}_experiments', experiment_name)
    print(f'Made Checkpoint Directory: {checkpoint_dir}')
    os.makedirs(checkpoint_dir, exist_ok=True)

     # Optionally resume from last checkpoint (control via CLI if you want)
    resume = True  # set True to resume from checkpoints/<...>/last
    start_epoch = 0
    if resume:
        print('Resuming from last checkpoint...')
        try:
            model_ckpt, state = load_model_from_checkpoint(args, best=True, map_location=DEVICE, load_optimizer=False)
            model = model_ckpt
            optimizer, scheduler = initialize_optimizer_and_scheduler(args, model, len(train_loader))
            model.to(DEVICE)
            if state is not None and state.get('epoch') is not None:
                start_epoch = state.get('epoch') + 1
            # If you want to restore optimizer/scheduler, call load_model_from_checkpoint with load_optimizer=True and pass optimizer/scheduler
        except FileNotFoundError:
            print('No checkpoint to resume; starting from scratch.')
    else:
        print('Starting training without checkpoint...')
        model = initialize_model(args)
        model.to(DEVICE)
        optimizer, scheduler = initialize_optimizer_and_scheduler(args, model, len(train_loader))
    print('Loaded Model')
    # Train 
    #train(args, model, train_loader, dev_loader, optimizer, scheduler)

    # Evaluate
    #model = load_model_from_checkpoint(args, best=True)
    model.eval()
    
    # Dev set
    experiment_name = args.experiment_name
    model_type = 'ft' if args.finetune else 'scr'
    gt_sql_path = os.path.join(f'data/dev.sql')
    gt_record_path = os.path.join(f'records/ground_truth_dev.pkl')
    model_sql_path = os.path.join(f'results/t5_{model_type}_{experiment_name}_dev.sql')
    model_record_path = os.path.join(f'records/t5_{model_type}_{experiment_name}_dev.pkl')
    dev_loss, dev_record_em, dev_record_f1, dev_sql_em, dev_error_rate = eval_epoch(args, model, dev_loader,
                                                                                    gt_sql_path, model_sql_path,
                                                                                    gt_record_path, model_record_path)
    print(f"Dev set results: Loss: {dev_loss}, Record F1: {dev_record_f1}, Record EM: {dev_record_em}, SQL EM: {dev_sql_em}")
    print(f"Dev set results: {dev_error_rate*100:.2f}% of the generated outputs led to SQL errors")

    # Test set
    model_sql_path = os.path.join(f'results/t5_{model_type}_{experiment_name}_test.sql')
    model_record_path = os.path.join(f'records/t5_{model_type}_{experiment_name}_test.pkl')
    test_inference(args, model, test_loader, model_sql_path, model_record_path)

if __name__ == "__main__":
    main()
